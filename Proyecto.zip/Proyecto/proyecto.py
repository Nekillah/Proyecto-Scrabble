#/////Proyecto final Scrabble ////////////
import tkinter as tk
from tkinter import messagebox
from tkinter import filedialog
import random
import os
import json
from datetime import datetime

#################### Clase principal del juego
class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False
        self.word = None

class Trie:
    def __init__(self):
        self.root = TrieNode()
    
    def insert(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_end_of_word = True
        node.word = word
    
    def search(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                return False
            node = node.children[char]
        return node.is_end_of_word
    
    def starts_with(self, prefix):
        node = self.root
        for char in prefix:
            if char not in node.children:
                return []
            node = node.children[char]
        return self._get_all_words(node)
    
    def _get_all_words(self, node):
        words = []
        if node.is_end_of_word:
            words.append(node.word)
        for child in node.children.values():
            words.extend(self._get_all_words(child))
        return words

class Dictionary:
    def __init__(self, filename):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(script_dir, filename)
        self.words = set()
        self.trie = Trie()
        
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                word = line.strip().upper()
                self.words.add(word)
                self.trie.insert(word)

    def is_valid(self, word):
        return word.upper() in self.words

    def find_words_with_prefix(self, prefix):
        return self.trie.starts_with(prefix.upper())

class ScrabbleGame:
    def __init__(self):
        self.players = []
        self.current_player = 0
        self.board = Board()
        self.bag = Bag()
        self.dictionary = Dictionary('diccionario.txt')
        self.game_over = False
        self.ensure_save_directory()
        self.max_saves = 5

    def ensure_save_directory(self):
        script_dir = os.path.dirname(os.path.abspath(__file__))
        self.save_dir = os.path.join(script_dir, "SaveStates")
        if not os.path.exists(self.save_dir):
            os.makedirs(self.save_dir)

    def get_save_info(self):
        saves = []
        for i in range(1, self.max_saves + 1):
            save_file = os.path.join(self.save_dir, f"save_{i}.json")
            if os.path.exists(save_file):
                with open(save_file, 'r', encoding='utf-8') as f:
                    try:
                        save_data = json.load(f)
                        saves.append({
                            'slot': i,
                            'name': save_data.get('save_name', 'Sin nombre'),
                            'date': save_data.get('save_date', ''),
                            'time': save_data.get('save_time', '')
                        })
                    except:
                        saves.append({
                            'slot': i,
                            'name': 'Archivo corrupto',
                            'date': '',
                            'time': ''
                        })
            else:
                saves.append({
                    'slot': i,
                    'name': 'Vacío',
                    'date': '',
                    'time': ''
                })
        return saves

    def save_game(self, slot, save_name):
        save_file = os.path.join(self.save_dir, f"save_{slot}.json")
        current_time = datetime.now()
        
        game_state = {
            'save_name': save_name,
            'save_date': current_time.strftime("%d/%m/%Y"),
            'save_time': current_time.strftime("%H:%M:%S"),
            'players': [
                {
                    'name': player.name,
                    'score': player.score,
                    'tiles': player.tiles,
                    'word_history': player.word_history
                } for player in self.players
            ],
            'current_player': self.current_player,
            'board': self.board.grid,
            'bag': self.bag.tiles,
            'game_over': self.game_over
        }
        with open(save_file, 'w', encoding='utf-8') as f:
            json.dump(game_state, f, ensure_ascii=False, indent=4)

    def load_game(self, slot):
        save_file = os.path.join(self.save_dir, f"save_{slot}.json")
        if os.path.exists(save_file):
            with open(save_file, 'r', encoding='utf-8') as f:
                game_state = json.load(f)
            
            self.players = []
            for player_data in game_state['players']:
                player = Player(player_data['name'])
                player.score = player_data['score']
                player.tiles = player_data['tiles']
                player.word_history = player_data['word_history']
                self.players.append(player)
            
            self.current_player = game_state['current_player']
            self.board.grid = game_state['board']
            self.bag.tiles = game_state['bag']
            self.game_over = game_state['game_over']
            return True
        return False

    def delete_save(self, slot):
        save_file = os.path.join(self.save_dir, f"save_{slot}.json")
        if os.path.exists(save_file):
            os.remove(save_file)
            return True
        return False

    def start_game(self, num_players):
        self.players = []
        for i in range(num_players):
            player = Player(f"Jugador {i+1}")
            player.tiles = self.bag.draw_tiles(7)
            self.players.append(player)
        self.current_player = 0

    def switch_player(self):
        self.current_player = (self.current_player + 1) % len(self.players)
        
    def calculate_score(self, word, pos, direction):
        points = {
            'A':1, 'E':1, 'O':1, 'I':1, 'S':1, 'N':1, 'L':1, 'R':1, 'U':1, 'T':1,
            'D':2, 'G':2, 'C':3, 'B':3, 'M':3, 'P':3, 'H':4, 'F':4, 'V':4, 'Y':4,
            'Q':5, 'J':8, 'Ñ':8, 'X':8, 'Z':10, ' ':0
        }
        x, y = pos
        total_score = 0
        word_multiplier = 1
        multipliers_used = []
        
        if direction == 'H':
            for i, letter in enumerate(word):
                letter_score = points.get(letter, 0)
                cell_multiplier = self.board.multipliers[x][y + i]
                if cell_multiplier > 1:
                    if cell_multiplier == 3:  # Triple palabra
                        word_multiplier *= 3
                        multipliers_used.append(('TP', (x, y + i)))
                    elif cell_multiplier == 2:  # Doble palabra
                        word_multiplier *= 2
                        multipliers_used.append(('DP', (x, y + i)))
                    else:  # Multiplicador de letra
                        letter_score *= cell_multiplier
                        multipliers_used.append(('DL' if cell_multiplier == 2 else 'TL', (x, y + i)))
                total_score += letter_score
        else:  # Vertical
            for i, letter in enumerate(word):
                letter_score = points.get(letter, 0)
                cell_multiplier = self.board.multipliers[x + i][y]
                if cell_multiplier > 1:
                    if cell_multiplier == 3:  # Triple palabra
                        word_multiplier *= 3
                        multipliers_used.append(('TP', (x + i, y)))
                    elif cell_multiplier == 2:  # Doble palabra
                        word_multiplier *= 2
                        multipliers_used.append(('DP', (x + i, y)))
                    else:  # Multiplicador de letra
                        letter_score *= cell_multiplier
                        multipliers_used.append(('DL' if cell_multiplier == 2 else 'TL', (x + i, y)))
                total_score += letter_score
        
        final_score = total_score * word_multiplier
        return final_score, multipliers_used

class Board:
    def __init__(self):
        self.grid = [[None for _ in range(15)] for _ in range(15)]
        self.multipliers = [[1 for _ in range(15)] for _ in range(15)]
        self.start_pos = (7, 7)
        self.initialize_multipliers()
    
    def initialize_multipliers(self):
        # Triple palabra
        for i in [0, 7, 14]:
            for j in [0, 7, 14]:
                self.multipliers[i][j] = 3
        
        # Doble palabra
        for i in [1, 2, 3, 4, 10, 11, 12, 13]:
            for j in [1, 2, 3, 4, 10, 11, 12, 13]:
                if (i + j) % 2 == 0:
                    self.multipliers[i][j] = 2
        
        # Triple letra
        for i in [1, 5, 9, 13]:
            for j in [5, 9]:
                self.multipliers[i][j] = 3
        
        # Doble letra
        for i in [0, 2, 6, 8, 12, 14]:
            for j in [3, 11]:
                self.multipliers[i][j] = 2
    
    def place_word(self, word, pos, direction):
        x, y = pos
        if direction == 'H':
            if y + len(word) > 15:
                return False
            # Verificar conexión con palabras existentes
            has_connection = False
            for i, letter in enumerate(word):
                if x > 0 and self.grid[x-1][y+i] is not None:
                    has_connection = True
                if x < 14 and self.grid[x+1][y+i] is not None:
                    has_connection = True
                if self.grid[x][y+i] is not None:
                    has_connection = True
            if not has_connection and not all(cell is None for row in self.grid for cell in row):
                return False
            for i, letter in enumerate(word):
                cell = self.grid[x][y + i]
                if cell is not None and cell != letter:
                    return False
            for i, letter in enumerate(word):
                self.grid[x][y + i] = letter
        elif direction == 'V':
            if x + len(word) > 15:
                return False
            # Verificar conexión con palabras existentes
            has_connection = False
            for i, letter in enumerate(word):
                if y > 0 and self.grid[x+i][y-1] is not None:
                    has_connection = True
                if y < 14 and self.grid[x+i][y+1] is not None:
                    has_connection = True
                if self.grid[x+i][y] is not None:
                    has_connection = True
            if not has_connection and not all(cell is None for row in self.grid for cell in row):
                return False
            for i, letter in enumerate(word):
                cell = self.grid[x + i][y]
                if cell is not None and cell != letter:
                    return False
            for i, letter in enumerate(word):
                self.grid[x + i][y] = letter
        else:
            return False
        return True

class Bag:
    def __init__(self):
        self.tiles = []
        self.initialize_bag()
        
    def initialize_bag(self):
        letters = {
            'A':12, 'E':12, 'O':9, 'I':6, 'S':6, 'N':5, 'L':4, 'R':5, 
            'U':5, 'T':4, 'D':5, 'G':2, 'C':4, 'B':2, 'M':2, 'P':2,
            'H':2, 'F':1, 'V':1, 'Y':1, 'Q':1, 'J':1,
            'Ñ':1, 'X':1, 'Z':1
        }
        for letter, count in letters.items():
            self.tiles.extend([letter]*count)
        random.shuffle(self.tiles)
    
    def draw_tiles(self, num):
        return [self.tiles.pop() for _ in range(num)]

class Player:
    def __init__(self, name):
        self.name = name
        self.score = 0
        self.tiles = []
        self.word_history = {}  # Tabla hash para almacenar palabras y sus detalles
        self.multiplier_history = {}  # Tabla hash para almacenar multiplicadores usados

    def add_word(self, word, score, position, direction, multipliers_used):
        if word not in self.word_history:
            self.word_history[word] = {
                'score': score,
                'position': position,
                'direction': direction,
                'multipliers': multipliers_used
            }

class WordSearcher:
    def __init__(self, dictionary):
        self.dictionary = dictionary
        self.words = sorted(list(dictionary.words))
    
    def search_words(self, pattern):
        pattern = pattern.upper()
        # Primero intentar búsqueda por prefijo usando el Trie
        prefix_matches = self.dictionary.find_words_with_prefix(pattern)
        if prefix_matches:
            return prefix_matches
        
        # Si no hay coincidencias por prefijo, buscar en toda la lista
        matches = []
        for word in self.words:
            if pattern in word:
                matches.append(word)
        return matches

class ScrabbleGUI:
    def __init__(self):
        self.game = None
        self.root = tk.Tk()
        self.easter_egg_clicks = 0
        self.create_intro_screen()
        
    def update_interface(self):
        self.clear_window()
        self.create_board()
        self.create_sidebar()
        self.show_current_player()
        
    def show_current_player(self):
        current = self.game.players[self.game.current_player]
        self.root.title(f"Turno de: {current.name} - Puntos: {current.score}")

    def create_intro_screen(self):
        self.clear_window()
        tk.Label(self.root, text="Bienvenido a Scrabble").pack()
        tk.Label(self.root, text=" ").pack()
        tk.Label(self.root, text="Reglas del juego").pack()
        tk.Label(self.root, text="1- Es un juego de dos jugadores por turnos clásico de scrabble").pack()
        tk.Label(self.root, text="2- Se permiten palabras cruzadas").pack()
        tk.Label(self.root, text="3- El juego se termina si un jugador se rinde o se terminan las fichas").pack()
        tk.Label(self.root, text="4- No se permiten palabras de abajo hacia arriba ni izquierda a derecha").pack()
        tk.Label(self.root, text="5- Solo se permiten las palabras que se encuentran en el diccionario(palabras en singular)").pack()
        tk.Label(self.root, text="6- El juego cuenta con un easter egg, ¡encuentralo!").pack()
        
        frame = tk.Frame(self.root)
        frame.pack(pady=10)
        
        tk.Button(frame, text="Nueva Partida", command=self.start_game).pack(side='left', padx=5)
        tk.Button(frame, text="Cargar Partida", command=self.load_game).pack(side='left', padx=5)

    def start_game(self):
        self.game = ScrabbleGame()
        self.game.start_game(2)
        self.update_interface()
    
    def create_board(self):
        frame = tk.Frame(self.root)
        for j in range(16):
            if j == 0:
                label = tk.Label(frame, text="", width=3, height=1, relief='ridge', bg='lightgray')
                label.grid(row=0, column=0)
                label.bind("<Button-1>", self.handle_easter_egg)
            else:
                tk.Label(frame, text=str(j), width=3, height=1, relief='ridge', bg='lightgray').grid(row=0, column=j)
        for i in range(1, 16):
            tk.Label(frame, text=str(i), width=3, height=1, relief='ridge', bg='lightgray').grid(row=i, column=0)
            for j in range(1, 16):
                letter = self.game.board.grid[i-1][j-1]
                multiplier = self.game.board.multipliers[i-1][j-1]
                display = letter if letter else ' '
                
                
                bg_color = 'white'
                if multiplier == 3:  # Triple palabra
                    bg_color = '#FF9999'  # Rosa claro
                elif multiplier == 2:  # Doble palabra
                    bg_color = '#FFCC99'  # Naranja claro
                elif multiplier == 3:  # Triple letra
                    bg_color = '#99CCFF'  # Azul claro
                elif multiplier == 2:  # Doble letra
                    bg_color = '#99FF99'  # Verde claro
                
                
                label = tk.Label(
                    frame,
                    text=display,
                    width=3,
                    height=1,
                    relief='ridge',
                    bg=bg_color
                )
                label.grid(row=i, column=j)
                
                # Agregar tooltip con información del multiplicador
                if multiplier > 1:
                    tooltip_text = f"{'Triple' if multiplier == 3 else 'Doble'} {'Palabra' if multiplier in [2, 3] else 'Letra'}"
                    self.create_tooltip(label, tooltip_text)
        
        frame.pack(side='left')

    def create_tooltip(self, widget, text):
        def show_tooltip(event):
            tooltip = tk.Toplevel()
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")
            
            label = tk.Label(tooltip, text=text, justify='left',
                           background="#ffffe0", relief='solid', borderwidth=1)
            label.pack()
            
            def hide_tooltip():
                tooltip.destroy()
            
            widget.tooltip = tooltip
            widget.bind('<Leave>', lambda e: hide_tooltip())
        
        widget.bind('<Enter>', show_tooltip)

    def handle_easter_egg(self, event):
        self.easter_egg_clicks += 1
        if self.easter_egg_clicks == 3:
            self.easter_egg_clicks = 0  
            self.show_easter_egg()

    def show_easter_egg(self):
        top = tk.Toplevel(self.root)
        top.title("¡Easter Egg!")
        tk.Label(top, text="Código original por Neko3g").pack()
        tk.Label(top, text="¡Gracias por jugar!").pack()

        tk.Button(top, text="Volver al juego", command=top.destroy).pack()

    def create_sidebar(self):
        frame = tk.Frame(self.root)
        current = self.game.players[self.game.current_player]
        tk.Label(frame, text=f"Player: {current.name}").pack(pady=(10, 2))
        tk.Label(frame, text="Fichas:").pack()
        self.tiles_display = tk.Label(frame, text=" ".join(current.tiles))
        self.tiles_display.pack(pady=(0, 10))
        
        options = [
            ("Escribir palabra", self.write_word),
            ("Reciclar fichas", self.recycle_tiles),
            ("Pasar turno", self.pass_turn),
            ("Guardar partida", self.save_game),
            ("Buscar palabras", self.show_word_searcher),
            ("Rendirse", self.surrender)
        ]
        for text, command in options:
            tk.Button(frame, text=text, command=command, width=15).pack(pady=10)
        frame.pack(side='bottom', fill='x', padx=15, pady=5)
    
    def write_word(self):
        popup = tk.Toplevel()
        popup.title("Colocar palabra")
        
        current_player = self.game.players[self.game.current_player]
        is_first_move = all(cell is None for row in self.game.board.grid for cell in row)

        tk.Label(popup, text="Palabra:").grid(row=0, column=0)
        word_entry = tk.Entry(popup)
        word_entry.grid(row=0, column=1)

        tk.Label(popup, text="Dirección:").grid(row=1, column=0)
        direction_var = tk.StringVar(value='H')
        tk.Radiobutton(popup, text="Horizontal", variable=direction_var, value='H').grid(row=1, column=1)
        tk.Radiobutton(popup, text="Vertical", variable=direction_var, value='V').grid(row=2, column=1)

        if not is_first_move:
            tk.Label(popup, text="Fila (1-15):").grid(row=3, column=0)
            row_entry = tk.Entry(popup)
            row_entry.grid(row=3, column=1)
            tk.Label(popup, text="Columna (1-15):").grid(row=4, column=0)
            col_entry = tk.Entry(popup)
            col_entry.grid(row=4, column=1)
        else:
            row_entry = None
            col_entry = None

        def try_place_word():
            word = word_entry.get().upper()
            if not self.game.dictionary.is_valid(word):
                messagebox.showerror("Error", "Palabra no existe en el diccionario")
                return

            direction = direction_var.get()
            if is_first_move:
                row, col = 7, 7
            else:
                try:
                    row = int(row_entry.get()) - 1
                    col = int(col_entry.get()) - 1
                except Exception:
                    messagebox.showerror("Error", "Coordenadas inválidas")
                    return

            needed = []
            for i, letter in enumerate(word):
                if direction == 'H':
                    cell = self.game.board.grid[row][col + i]
                else:
                    cell = self.game.board.grid[row + i][col]
                if cell is None:
                    needed.append(letter)
                elif cell != letter:
                    messagebox.showerror("Error", "Conflicto con letras en el tablero")
                    return

            tiles_copy = current_player.tiles.copy()
            for letter in needed:
                if letter in tiles_copy:
                    tiles_copy.remove(letter)
                else:
                    messagebox.showerror("Error", "No tienes las letras necesarias")
                    return

            if not self.game.board.place_word(word, (row, col), direction):
                messagebox.showerror("Error", "Posición inválida o excede límites del tablero")
                return

            score, multipliers_used = self.game.calculate_score(word, (row, col), direction)
            current_player.score += score
            current_player.add_word(word, score, (row, col), direction, multipliers_used)

            for letter in needed:
                current_player.tiles.remove(letter)
            new_tiles = self.game.bag.draw_tiles(len(needed))
            current_player.tiles.extend(new_tiles)

            self.game.switch_player()
            self.update_interface()
            popup.destroy()

        tk.Button(popup, text="Colocar", command=try_place_word).grid(row=5, columnspan=2)

    def recycle_tiles(self):
        popup = tk.Toplevel()
        popup.title("Reciclar fichas")
        
        current_player = self.game.players[self.game.current_player]
        selected = []
        checkbuttons = []
        def toggle_tile(index, var):
            if var.get():
                if len(selected) < 3:
                    selected.append(index)
                else:
                    var.set(False)
                    messagebox.showerror("Error", "Solo puedes reciclar hasta 3 fichas.")
            else:
                if index in selected:
                    selected.remove(index)
                    
        tk.Label(popup, text="Selecciona hasta 3 fichas para reciclar").pack()
        
        for i, tile in enumerate(current_player.tiles):
            var = tk.BooleanVar()
            btn = tk.Checkbutton(popup, text=tile, variable=var, 
                                 command=lambda idx=i, v=var: toggle_tile(idx, v))
            btn.pack()
            checkbuttons.append(var)
            
        def confirm_recycle():
            if not selected:
                messagebox.showerror("Error", "Debes seleccionar al menos 1 ficha")
                return

            indices = sorted(selected, reverse=True)
            recycled = []
            for idx in indices:
                recycled.append(current_player.tiles.pop(idx))

            self.game.bag.tiles.extend(recycled)
            random.shuffle(self.game.bag.tiles)
            nuevas = min(len(recycled), len(self.game.bag.tiles))
            new_tiles = self.game.bag.draw_tiles(nuevas)
            current_player.tiles.extend(new_tiles)

            self.game.switch_player()
            self.update_interface()
            popup.destroy()
            
        tk.Button(popup, text="Confirmar", command=confirm_recycle).pack()
        
    def pass_turn(self):
        self.game.switch_player()
        self.update_interface()
        
    def surrender(self):
        winner = (self.game.current_player + 1) % 2
        loser = self.game.current_player
        winner_score = self.game.players[winner].score
        loser_score = self.game.players[loser].score

        final_win = tk.Toplevel(self.root)
        final_win.title("Fin del juego")
        final_win.geometry("800x600")

        # Frame para el resumen
        summary_frame = tk.Frame(final_win)
        summary_frame.pack(pady=10)
        
        tk.Label(
            summary_frame,
            text=f"¡El ganador es {self.game.players[winner].name} con {winner_score} puntos!",
            font=("Arial", 14, "bold")
        ).pack()
        tk.Label(
            summary_frame,
            text=f"El perdedor es {self.game.players[loser].name} con {loser_score} puntos.",
            font=("Arial", 12)
        ).pack()

        # Frame para las tablas de jugadores
        tables_frame = tk.Frame(final_win)
        tables_frame.pack(fill='both', expand=True, padx=20, pady=10)

        # Tabla para el ganador
        winner_frame = tk.LabelFrame(tables_frame, text=f"Palabras de {self.game.players[winner].name}")
        winner_frame.pack(side='left', fill='both', expand=True, padx=10)
        
        # Encabezados
        headers = ["Palabra", "Puntos", "Posición", "Multiplicadores"]
        for i, header in enumerate(headers):
            tk.Label(winner_frame, text=header, font=("Arial", 10, "bold")).grid(row=0, column=i, padx=5, pady=5)
        
        # Datos del ganador
        row = 1
        for word, details in self.game.players[winner].word_history.items():
            tk.Label(winner_frame, text=word).grid(row=row, column=0, padx=5, pady=2)
            tk.Label(winner_frame, text=str(details['score'])).grid(row=row, column=1, padx=5, pady=2)
            pos_text = f"({details['position'][0]+1},{details['position'][1]+1}) {details['direction']}"
            tk.Label(winner_frame, text=pos_text).grid(row=row, column=2, padx=5, pady=2)
            
            # Mostrar multiplicadores usados
            mult_text = ", ".join([f"{m[0]}({m[1][0]+1},{m[1][1]+1})" for m in details['multipliers']])
            tk.Label(winner_frame, text=mult_text).grid(row=row, column=3, padx=5, pady=2)
            row += 1

        # Tabla para el perdedor
        loser_frame = tk.LabelFrame(tables_frame, text=f"Palabras de {self.game.players[loser].name}")
        loser_frame.pack(side='right', fill='both', expand=True, padx=10)
        
        # Encabezados
        for i, header in enumerate(headers):
            tk.Label(loser_frame, text=header, font=("Arial", 10, "bold")).grid(row=0, column=i, padx=5, pady=5)
        
        # Datos del perdedor
        row = 1
        for word, details in self.game.players[loser].word_history.items():
            tk.Label(loser_frame, text=word).grid(row=row, column=0, padx=5, pady=2)
            tk.Label(loser_frame, text=str(details['score'])).grid(row=row, column=1, padx=5, pady=2)
            pos_text = f"({details['position'][0]+1},{details['position'][1]+1}) {details['direction']}"
            tk.Label(loser_frame, text=pos_text).grid(row=row, column=2, padx=5, pady=2)
            
            # Mostrar multiplicadores usados
            mult_text = ", ".join([f"{m[0]}({m[1][0]+1},{m[1][1]+1})" for m in details['multipliers']])
            tk.Label(loser_frame, text=mult_text).grid(row=row, column=3, padx=5, pady=2)
            row += 1

        # Botón para salir
        tk.Button(final_win, text="Salir", 
                 command=lambda: [final_win.destroy(), self.create_intro_screen()]).pack(pady=10)
        
        self.game.game_over = True

    def clear_window(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_save_load_dialog(self, is_save=True):
        dialog = tk.Toplevel(self.root)
        dialog.title("Guardar Partida" if is_save else "Cargar Partida")
        dialog.geometry("600x400")
        
        # Frame para la tabla
        table_frame = tk.Frame(dialog)
        table_frame.pack(pady=10, padx=10, fill='both', expand=True)
        
        # Encabezados
        headers = ["Slot", "Nombre", "Fecha", "Hora"]
        for i, header in enumerate(headers):
            tk.Label(table_frame, text=header, font=("Arial", 10, "bold")).grid(row=0, column=i, padx=5, pady=5)
        
        # Obtener información de guardados
        saves = self.game.get_save_info()
        
        # Variables para almacenar la selección
        selected_slot = tk.IntVar()
        
        # Mostrar slots
        for i, save in enumerate(saves, 1):
            tk.Radiobutton(table_frame, variable=selected_slot, value=save['slot']).grid(row=i, column=0, padx=5, pady=2)
            tk.Label(table_frame, text=save['name']).grid(row=i, column=1, padx=5, pady=2)
            tk.Label(table_frame, text=save['date']).grid(row=i, column=2, padx=5, pady=2)
            tk.Label(table_frame, text=save['time']).grid(row=i, column=3, padx=5, pady=2)
        
        # Frame para el nombre del guardado (solo al guardar)
        name_frame = tk.Frame(dialog)
        name_frame.pack(pady=10)
        
        if is_save:
            tk.Label(name_frame, text="Nombre del guardado:").pack(side='left')
            save_name = tk.Entry(name_frame)
            save_name.pack(side='left', padx=5)
        
        def confirm():
            slot = selected_slot.get()
            if is_save:
                name = save_name.get().strip()
                if not name:
                    messagebox.showerror("Error", "Debes ingresar un nombre para el guardado")
                    return
                self.game.save_game(slot, name)
                messagebox.showinfo("Guardado", "Partida guardada exitosamente")
            else:
                if self.game.load_game(slot):
                    self.update_interface()
                else:
                    messagebox.showerror("Error", "No se pudo cargar la partida")
            dialog.destroy()

        def delete_save():
            slot = selected_slot.get()
            if slot:
                save_info = next((s for s in saves if s['slot'] == slot), None)
                if save_info and save_info['name'] != 'Vacío':
                    if messagebox.askyesno("Confirmar", f"¿Estás seguro de eliminar el guardado '{save_info['name']}'?"):
                        if self.game.delete_save(slot):
                            messagebox.showinfo("Éxito", "Guardado eliminado correctamente")
                            dialog.destroy()
                            self.show_save_load_dialog(is_save)
                        else:
                            messagebox.showerror("Error", "No se pudo eliminar el guardado")
                else:
                    messagebox.showinfo("Información", "No hay guardado para eliminar en este slot")
            else:
                messagebox.showinfo("Información", "Selecciona un slot para eliminar")
        
        # Botones
        button_frame = tk.Frame(dialog)
        button_frame.pack(pady=10)
        tk.Button(button_frame, text="Confirmar", command=confirm).pack(side='left', padx=5)
        if not is_save:
            tk.Button(button_frame, text="Eliminar", command=delete_save).pack(side='left', padx=5)
        tk.Button(button_frame, text="Cancelar", command=dialog.destroy).pack(side='left', padx=5)

    def load_game(self):
        self.show_save_load_dialog(is_save=False)

    def save_game(self):
        self.show_save_load_dialog(is_save=True)

    def show_word_searcher(self):
        searcher = WordSearcher(self.game.dictionary)
        search_window = tk.Toplevel(self.root)
        search_window.title("Buscador de Palabras")
        search_window.geometry("400x500")
        
        # Frame para la búsqueda
        search_frame = tk.Frame(search_window)
        search_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(search_frame, text="Buscar palabra:").pack(side='left')
        search_entry = tk.Entry(search_frame)
        search_entry.pack(side='left', fill='x', expand=True, padx=5)
        
        # Lista de resultados
        results_frame = tk.Frame(search_window)
        results_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        scrollbar = tk.Scrollbar(results_frame)
        scrollbar.pack(side='right', fill='y')
        
        results_list = tk.Listbox(results_frame, yscrollcommand=scrollbar.set)
        results_list.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=results_list.yview)
        
        def update_results(*args):
            pattern = search_entry.get()
            results_list.delete(0, tk.END)
            matches = searcher.search_words(pattern)
            for word in matches:
                results_list.insert(tk.END, word)
        
        search_entry.bind('<KeyRelease>', update_results)
        
        # Botón para usar la palabra seleccionada
        def use_selected_word():
            selection = results_list.curselection()
            if selection:
                word = results_list.get(selection[0])
                search_window.destroy()
                self.write_word_with_word(word)
        
        tk.Button(search_window, text="Usar palabra seleccionada", 
                 command=use_selected_word).pack(pady=10)
        
        # Mostrar resultados iniciales
        update_results()

    def write_word_with_word(self, word):
        popup = tk.Toplevel()
        popup.title("Colocar palabra")
        
        current_player = self.game.players[self.game.current_player]
        is_first_move = all(cell is None for row in self.game.board.grid for cell in row)

        tk.Label(popup, text=f"Palabra: {word}").pack()

        tk.Label(popup, text="Dirección:").pack()
        direction_var = tk.StringVar(value='H')
        tk.Radiobutton(popup, text="Horizontal", variable=direction_var, value='H').pack()
        tk.Radiobutton(popup, text="Vertical", variable=direction_var, value='V').pack()

        if not is_first_move:
            pos_frame = tk.Frame(popup)
            pos_frame.pack(pady=5)
            
            tk.Label(pos_frame, text="Fila (1-15):").pack(side='left')
            row_entry = tk.Entry(pos_frame, width=5)
            row_entry.pack(side='left', padx=5)
            
            tk.Label(pos_frame, text="Columna (1-15):").pack(side='left')
            col_entry = tk.Entry(pos_frame, width=5)
            col_entry.pack(side='left', padx=5)
        else:
            row_entry = None
            col_entry = None

        def try_place_word():
            direction = direction_var.get()
            if is_first_move:
                row, col = 7, 7
            else:
                try:
                    row = int(row_entry.get()) - 1
                    col = int(col_entry.get()) - 1
                except Exception:
                    messagebox.showerror("Error", "Coordenadas inválidas")
                    return

            needed = []
            for i, letter in enumerate(word):
                if direction == 'H':
                    cell = self.game.board.grid[row][col + i]
                else:
                    cell = self.game.board.grid[row + i][col]
                if cell is None:
                    needed.append(letter)
                elif cell != letter:
                    messagebox.showerror("Error", "Conflicto con letras en el tablero")
                    return

            tiles_copy = current_player.tiles.copy()
            for letter in needed:
                if letter in tiles_copy:
                    tiles_copy.remove(letter)
                else:
                    messagebox.showerror("Error", "No tienes las letras necesarias")
                    return

            if not self.game.board.place_word(word, (row, col), direction):
                messagebox.showerror("Error", "Posición inválida o excede límites del tablero")
                return

            score, multipliers_used = self.game.calculate_score(word, (row, col), direction)
            current_player.score += score
            current_player.add_word(word, score, (row, col), direction, multipliers_used)

            for letter in needed:
                current_player.tiles.remove(letter)
            new_tiles = self.game.bag.draw_tiles(len(needed))
            current_player.tiles.extend(new_tiles)

            self.game.switch_player()
            self.update_interface()
            popup.destroy()

        tk.Button(popup, text="Colocar", command=try_place_word).pack(pady=10)

if __name__ == "__main__":
    app = ScrabbleGUI()
    app.root.mainloop()